<?php
/**
 * @author dogwin
 * @date 2013-03-07
 */
?>
<p class="link">首页 》了解玉佛寺 》</p>
<?php 
/*End the file link.php*/
/*Location /themes/jade/link.php*/