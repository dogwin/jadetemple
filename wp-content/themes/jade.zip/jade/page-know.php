<?php
/**
 * @author dogwin
 * @date 2013-03-07
 */
get_header('intro');
?>
<div id="know_left">
	<?php get_template_part('know_left');?>
</div><!-- #know_left -->
<div id="primary" class="site-content">
	
</div><!-- #primary -->
<div class="clear"></div><!-- .clear -->

<?php 
get_footer();
/*End the file page-know.php*/
/*Loaction /themes/jade/page-know.php*/