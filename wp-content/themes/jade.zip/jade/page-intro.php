<?php
/**
 * @author dogwin
 * @date 2013-03-07
 */
get_header('intro');
?>
<div id="primary" class="site-content">
	<div id="know_left">
		<?php get_template_part('know_left');?>
	</div><!-- #know_left -->
	<div id="know_right">
		
	</div><!-- #know_right -->
	<div class="clear"></div>
</div><!-- #primary -->
<?php
get_footer();
/*End the file page-intro.php*/
/*Location /themes/jade/page-intro.php*/